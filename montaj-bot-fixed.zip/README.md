# Montaj Bot

Telegram-бот для расчета стоимости монтажных работ по видеонаблюдению.

## Запуск

1. Установите зависимости:
```
pip install -r requirements.txt
```

2. Задайте переменную окружения BOT_TOKEN (полученную от @BotFather).
3. Запустите бота:
```
python montaj_bot.py
```

## Деплой на Render

- Build command: pip install -r requirements.txt
- Start command: python montaj_bot.py
- Environment variable: BOT_TOKEN=<ваш_токен>